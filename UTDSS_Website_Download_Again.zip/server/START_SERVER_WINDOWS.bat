@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo Install Node.js 22 or later.& pause & exit /b 1)
if not exist .env (copy .env.example .env >nul & echo Created .env. Add your authorised API and email credentials before enabling live services. & pause & exit /b 1)
if not exist node_modules (call npm install)
if errorlevel 1 (echo Dependency installation failed. Check network and Node.js version.& pause & exit /b 1)
node --env-file=.env server.js
pause
