# Domain and public website launch — UTDSS

## Domain
The suggested domain is `utdss.com`, based on the requested UTDSS website name, **but ownership/registration must be confirmed**. Domain registration and hosting are different services.

## What is configured
- Website with logo, images and product catalogue
- RFQ table for description / NSN / MPN or part number / quantity / remarks
- Outlook Web compose deeplink, including prefilled recipient, subject and item data (customer clicks Send in Outlook)
- Server contact endpoint designed to deliver emails through configured SMTP
- AI chat and neural TTS endpoints requiring paid API credentials
- Render Docker deployment blueprint

## How to publish using Render
1. Connect a private GitHub repository containing this directory (never commit `.env` or secrets).
2. Use Render to deploy a Docker web service from the repository, region Singapore.
3. Add `OPENAI_API_KEY`, `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM` securely in Render settings.
4. Confirm `/api/health` and send real tests. Health reports configuration, not proof of delivery.
5. In Render Settings > Custom Domains, add the verified domain you own. Follow the specific DNS instructions Render provides and configure records with the registrar/DNS provider.
6. Verify HTTPS and test `www`, forms, AI, audio, image loading and the customer inbox.

## Email behavior
- `Open in Outlook` opens Outlook on the web with a prefilled draft; requires an Outlook account and **does not send automatically**.
- `Send Message` uses server-side SMTP and must show success only after the server confirms delivery.
- If a user does not have Outlook, they may use the direct email link in Contact Us.

## Cautions
Do not publish the draft T&C as legally approved. Confirm the company telephone number, CEO title, product availability, aviation capability and any government client/contract claims before launch. Add privacy notice and anti-spam protection before production use.
